package com.example.avaliacao1;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

public class ContasActivity extends AppCompatActivity {


    private ArrayAdapter<Conta> contaAdapter;
    private Categoria categoria;
    private LinkedList<Conta> contas;
    private ListView listContasView;
    private EditText edValor;
    private EditText edDescricao;
    private TextView txtData;
    private Date data;
    private int selecionado = -1;
    private boolean editando = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contas);

        listContasView = findViewById(R.id.listaContas);
        edValor = findViewById(R.id.valor_conta);
        edDescricao = findViewById(R.id.descricao_conta);
        txtData = findViewById(R.id.txt_data);

        categoria = new Categoria();
        contas = new LinkedList<>();

        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            categoria = (Categoria) extras.getSerializable("categoria");
            if (categoria != null) {
                TextView txtCategoria = findViewById(R.id.txt_categoria);
                txtCategoria.setText(categoria.getDescricao());
                contas = categoria.getContas();
            }
        }

        contaAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, contas);
        listContasView.setAdapter(contaAdapter);

        listContasView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selecionado = position;
                contaAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_contas, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.item_confirmar) {
            confirmarConta(null);
            return true;
        }

        if (item.getItemId() == R.id.item_editar) {
            editar(null);
            return true;
        }

        if (item.getItemId() == R.id.item_remover) {
            remover(null);
            return true;
        }

        if(item.getItemId() == R.id.item_voltar){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }


    public void registrar(View v) {
        DatePickerDialog dpd = new DatePickerDialog(this);
        dpd.setOnDateSetListener((view, ano, mes, dia) -> {
            data = new Date(ano - 1900, mes, dia);
            TextView dt = (TextView) findViewById(R.id.txt_data);
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            dt.setText(sdf.format(data));
        });
        dpd.show();
    }

    public void remover(View v) {
        if(selecionado == -1){
            Toast.makeText(this, R.string.selecionar_item_remocao, Toast.LENGTH_SHORT).show();
        }else{
            contas.remove(selecionado);
            contaAdapter.notifyDataSetChanged();
            Toast.makeText(this, R.string.item_removido, Toast.LENGTH_SHORT).show();
        }
    }


    public void confirmarConta(View v) {
        if (TextUtils.isEmpty(edValor.getText().toString())
                || TextUtils.isEmpty(edDescricao.getText().toString())
                || TextUtils.isEmpty(txtData.getText().toString())) {
            Toast.makeText(this, R.string.msg_preencher_campos, Toast.LENGTH_SHORT).show();
        } else {
            if (editando) {
                if (selecionado != -1 && selecionado < contas.size()) {
                    Conta c = contas.get(selecionado);
                    c.setDescricao(edDescricao.getText().toString());
                    c.setValor(Double.parseDouble(edValor.getText().toString()));
                    c.setVencimento(data);
                    editando = false;
                    contaAdapter.notifyDataSetChanged();
                    Toast.makeText(this, R.string.alteracao_feita, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, R.string.selecione_uma_conta_para_editar, Toast.LENGTH_SHORT).show();
                }
            } else {
                Conta novaConta = new Conta();
                novaConta.setDescricao(edDescricao.getText().toString());
                novaConta.setValor(Double.parseDouble(edValor.getText().toString()));
                novaConta.setVencimento(data);

                categoria.addConta(novaConta);
                contaAdapter.notifyDataSetChanged();

                Toast.makeText(this, R.string.cadastro_realizado, Toast.LENGTH_SHORT).show();
            }
        }

        edDescricao.setText("");
        edValor.setText("");
        txtData.setText("Data vencimento");

    }

    public void editar(View v) {
        editando = true;
        if (selecionado != -1 && selecionado < contas.size()) {
            Conta c = contas.get(selecionado);
            if (c != null) {
                edDescricao.setText(c.getDescricao());
                edValor.setText(String.valueOf(c.getValor()));
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                txtData.setText(sdf.format(c.getVencimento()));
            } else {
                Toast.makeText(this, R.string.selecionar_item_edicao, Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, R.string.selecionar_item_edicao, Toast.LENGTH_SHORT).show();
        }
    }





}