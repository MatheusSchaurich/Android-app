package com.example.avaliacao1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

public class Categoria implements Serializable {
    private String descricao;
    private LinkedList<Conta> contas = new LinkedList<>();

    public Categoria(String descricao) {

        this.descricao = descricao;
    }

    public Categoria() {
    }

    public String toString(){
        return descricao+ " . " + (contas == null ? 0 : contas.size());
    }

    public String getDescricao() {

        return descricao ;
    }

    public void setDescricao(String descricao) {

        this.descricao = descricao;
    }

    public LinkedList<Conta> getContas() {
        return contas;
    }

    public void setContas(LinkedList<Conta> contas) {
        this.contas = contas;
    }

    public void addConta(Conta c){
        contas.add(c);
    }

}
