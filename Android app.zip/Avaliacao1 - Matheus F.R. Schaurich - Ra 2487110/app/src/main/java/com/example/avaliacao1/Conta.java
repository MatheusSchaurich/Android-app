package com.example.avaliacao1;

import android.icu.text.SimpleDateFormat;

import java.io.Serializable;
import java.util.Date;

public class Conta implements Serializable {
    private String descricao;
    private Date vencimento;
    private double valor;
    private Categoria categoria;

    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public Conta(String descricao, Date vencimento, double valor, Categoria categoria) {
        this.descricao = descricao;
        this.vencimento = vencimento;
        this.valor = valor;
        this.categoria = categoria;
    }

    public Conta() {
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getVencimento() {
        return vencimento;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public String toString() {
        return descricao + " - R$" + valor + " - " + sdf.format(vencimento);
    }

    public void setVencimento(Date data) {
        this.vencimento = data;
    }
}
