package com.example.avaliacao1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {

    class CategoriaAdapter extends ArrayAdapter<Categoria> {
        public CategoriaAdapter() {
            super(MainActivity.this, android.R.layout.simple_list_item_1, categorias);
        }
    }

    private LinkedList<Categoria> categorias;

    ListView listCategoriasView;
    ArrayAdapter<Categoria> adapter;

    private Conta conta;

    EditText edCategoria;

    int selecionado = -1;

    boolean editando = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listCategoriasView = findViewById(R.id.listaCategorias);

        categorias = new LinkedList<>();

        if (savedInstanceState != null) {
            categorias = (LinkedList<Categoria>) savedInstanceState.getSerializable("LISTA CATEGORIAS");
            selecionado = savedInstanceState.getInt("SELECIONADO", -1);
        }

        adapter = new CategoriaAdapter();
        listCategoriasView.setAdapter(adapter);

        listCategoriasView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                selecionado = position;
                adapter.notifyDataSetChanged();
            }
        });


    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_categorias_contas, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.item_confirmar){
            confirmar(null);
            return true;
        }

        if (item.getItemId() == R.id.item_editar){
            editar(null);
            return true;
        }

        if (item.getItemId() == R.id.item_remover){
            remover(null);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void confirmar(View v) {
        Categoria categoria = new Categoria();
        edCategoria = findViewById(R.id.categoria);
        if (edCategoria.getText().toString() == null || edCategoria.getText().toString().isEmpty()) {
            Toast.makeText(this, R.string.msg_preencher_campos, Toast.LENGTH_SHORT).show();
        } else {
            if (editando) {
                Categoria c = categorias.get(selecionado);
                c.setDescricao(edCategoria.getText().toString());
                categorias.set(selecionado, c);
                edCategoria.setText("");
                editando = false;
                adapter.notifyDataSetChanged();
                Toast.makeText(this, R.string.alteracao_feita, Toast.LENGTH_SHORT).show();
            } else {
                categoria.setDescricao(edCategoria.getText().toString());
                categorias.add(categoria);
                edCategoria.setText("");
                adapter.notifyDataSetChanged();
                Toast.makeText(this, "Categoria cadastrada", Toast.LENGTH_SHORT).show();
            }
        }


    }

    public void editar(View v) {
        editando = true;
        if (listCategoriasView != null) {
            Categoria c = categorias.get(selecionado);
            if (c == null) {
                Toast.makeText(this, "Selecione a descrição a editar", Toast.LENGTH_SHORT).show();
            } else {
                edCategoria.setText(c.getDescricao());
            }
        }
    }

    public void cadastrarConta(View v){
        Categoria c = categorias.get(selecionado);
        Intent intent = new Intent(this, ContasActivity.class);
        intent.putExtra("categoria", c);
        startActivityForResult(intent, 123);
    }

    @Override
    public void onActivityResult(int req, int res, Intent dados) {
        super.onActivityResult(req, res, dados);
        if (req == 123 && res == RESULT_OK) {
            Conta conta = (Conta) dados.getSerializableExtra("conta");
            Categoria c = categorias.get(selecionado);
            c.addConta(conta);
            adapter.notifyDataSetChanged();
        }
    }


    public void remover(View v) {
        if(selecionado == -1){
            Toast.makeText(this, "Selecione a descrição a editar", Toast.LENGTH_SHORT).show();
        }else{
            categorias.remove(selecionado);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Descrição removida!", Toast.LENGTH_SHORT).show();
        }
    }
}